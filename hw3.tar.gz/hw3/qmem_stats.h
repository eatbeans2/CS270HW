
int qmem_addVar(void * newAddress);

int qmem_delVar(void * oldAddress);

int qmem_findVar(void * searchAddress); 
