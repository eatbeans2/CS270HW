
int bubbleSort(char** arrays, int arraySize, int stringSize);

int checkValues(char* word1, char*word2, int stringSize);
