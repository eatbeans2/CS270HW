
int quickSort(char** arrays, int stringCount, int stringLength, int low, int high);

int partition(char** arrays, int stringLength, int low, int high);
