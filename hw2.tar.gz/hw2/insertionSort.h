
int insertionSort(char** arrays, int stringCount, int stringLength);

void insert(char** arrays, int x, int stringCount, int stringLength);
